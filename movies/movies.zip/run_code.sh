#!/bin/bash
echo running
echo make sure you pip install sklearn if you dont have it already
python3 main.py